# Atendance

## Install
- ## Backend (Api)
```bash
$ composer install
$ php artisan migrate:fresh --seed
$ php artisan serve
```

- ## Fe (Frontend)

```bash
$ npm install
$ npm serve
```


## Cara Pengunaan

**admin**
- login 
[ (email: ``attendance@admin.com``, password: ``Password``) ]

![admin, login admin](/doc/page-login.png)

- generate QRCode
![admin, login admin](/doc/page-generate-qr.png)

- report
![admin, report](/doc/page-report.png)

- generate QRCode
![admin, login admin](/doc/page-report.png)


**users**
- login
![user, login user](/doc/page-login.png)
- home
![user, homeuser](/doc/page-home.png)
- attendance
![user, attendance user](/doc/page-attendance.png)

![user, clock user](/doc/page-clock-in.png)
NB: scan QR code (base_url_api, example: http://localhost:8000/)
![user, scan qr user](/doc/scan-qr.png)


<hr/>

## Use Case
![Use case](/doc/wsd-use-case.png)
## Design Database
![Use case](/doc/wsd-design-database.png)
## System Architecture
![Use case](/doc/wsd-system-architecture.png)
## Activity Attendance
![Use case](/doc/wsd-activity-attendance.png)
## Activity Report
![Use case](/doc/wsd-activity-report.png)
