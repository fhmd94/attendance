<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\ReportController;
use App\Http\Controllers\Api\AccountController;
use App\Http\Controllers\Api\AttendanceController;
use App\Http\Controllers\Api\AuthenticationController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });

Route::post('login', [AuthenticationController::class, 'authenticate']);
Route::post('logout', [AuthenticationController::class, 'logout']);

Route::group(['middleware' => ['auth:api']], function() {
    Route::get('account/me', [AccountController::class, 'index']);
    Route::post('clock-in', [AttendanceController::class, 'clock_in']);
    Route::post('clock-out', [AttendanceController::class, 'clock_out']);

    Route::apiResource('users', UserController::class);
    Route::apiResource('attendance', AttendanceController::class);
    Route::get('list-users', [UserController::class, 'index']);
    Route::get('report', [ReportController::class, 'index']);
    Route::get('report/{id}', [ReportController::class, 'show']);
});
