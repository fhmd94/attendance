<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Attendance extends Model
{
    use HasFactory;
    protected $table = 'attendance';

    public function users()
    {
        return $this->belongsToMany(User::class, 'attendance_user')->withPivot(
            'clock_in_at',
            'clock_out_at',
            'latitude',
            'longitude',
        );
    }

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        // 'day' => 'date:Y-m-d',
        // 'clock_out_at' => 'datetime',
    ];

    protected $fillable = [
        'day',
        'token',
        'url_qr_code',
    ];
}
