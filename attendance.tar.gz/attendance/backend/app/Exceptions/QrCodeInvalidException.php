<?php

namespace App\Exceptions;

use Exception;

class QrCodeInvalidException extends Exception
{
    //
}
