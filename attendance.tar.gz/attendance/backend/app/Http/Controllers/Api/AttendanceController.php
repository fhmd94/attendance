<?php

namespace App\Http\Controllers\Api;

use Carbon\Carbon;
use App\Models\Attendance;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Exceptions\QrCodeInvalidException;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use App\Exceptions\NotExistAttendanceException;

class AttendanceController extends Controller
{
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $request["user_id"] = $request->user()->id;
            return $next($request);
        });
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Attendance::orderBy('day', 'desc')->paginate();

        return response()->json([
            'data' => $data
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'day' => 'required|date:Y-m-d|unique:attendance,day'
        ]);

        $token = Str::random(180);
        $data = [
            'date' => $request->day,
            'token' => $token,
        ];
        $timestamp = Carbon::now()->timestamp;
        $path =  public_path('qr_code/'.$timestamp.'.png');
        $url = url('qr_code/'.$timestamp.'.png');

        QrCode::size(1200)
            ->format('png')
            ->generate(json_encode($data), $path);

        $attendance = Attendance::create([
            'day' => $request->day,
            'token' => $token,
            'url_qr_code' => $url
        ]);

        return response()->json([
            'success' =>  true,
            'data' => $attendance
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }



    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function clock_in(Request $request)
    {
        $request->validate([
            'user_id' => 'required',
            'date' => 'required',
            'latitude' => 'required',
            'longitude' => 'required',
            'token_attendance' => 'required'
        ]);

        $userId = $request->user()->id;

        if (Carbon::parse($request->date)->format('Y-m-d') != Carbon::now()->format('Y-m-d') ) {
            // throw new QrCodeInvalidException(__("QR Code Not Validate"));
            return response()->json([
                'status' => false,
                'message' => __("QR Code Not Validate")
            ]);
        }

        $attendance = Attendance::where([
            'day' => $request->date,
            'token' => $request->token_attendance
        ])->first();
        if (!$attendance) {
            // throw new NotExistAttendanceException(__("Daftar Hadir Belum Tersedia"));
            return response()->json([
                'status' => false,
                'message' => __("Daftar Hadir Belum Tersedia")
            ]);
        }

        $userAtt = Attendance::whereHas('users', function ($query)  use($userId) {
            $query->where('user_id', $userId);
        })->with(['users' => function ($query) use($userId) {
            $query->where('user_id', $userId);
        }])->find($attendance->id);

        if (!$userAtt) {
            $attendance->users()->attach($userId, [
                'clock_in_at' => Carbon::now(),
                'latitude' => $request->latitude,
                'longitude' => $request->longitude
            ]);
        }

        $userAtt = Attendance::whereHas('users', function ($query)  use($userId) {
            $query->where('user_id', $userId);
        })->with(['users' => function ($query) use($userId) {
            $query->where('user_id', $userId);
        }])->find($attendance->id);

        return response()->json([
            'success' => true,
            'data' => $userAtt->users()->first()->pivot
        ]);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function clock_out(Request $request)
    {
        $request->validate([
            'user_id' => 'required',
            'date' => 'required',
            'latitude' => 'required',
            'longitude' => 'required',
            'token_attendance' => 'required'
        ]);
        $userId = $request->user()->id;


        if (Carbon::parse($request->date)->format('Y-m-d') != Carbon::now()->format('Y-m-d') ) {
            // throw new QrCodeInvalidException(__("QR Code Not Validate"));
            return response()->json([
                'status' => false,
                'message' => __("QR Code Not Validate")
            ]);
        }

        $attendance = Attendance::where([
            'day' => $request->date,
            'token' => $request->token_attendance
        ])->first();

        if (!$attendance) {
            // throw new NotExistAttendanceException(__("Daftar Hadir Belum Tersedia"));
            return response()->json([
                'status' => false,
                'message' => __("Daftar Hadir Belum Tersedia")
            ]);
        }

        $userAtt = Attendance::whereHas('users', function ($query)  use($userId) {
            $query->where('user_id', $userId)->whereNull('clock_out_at');
        })->with(['users' => function ($query) use($userId) {
            $query->where('user_id', $userId);
        }])->find($attendance->id);

        // TODO: chek latitude & longitude

        if (!$userAtt) {
            $attendance->users()->syncWithPivotValues($userId, [
                'clock_out_at' => Carbon::now()
            ]);
        }

        $userAtt = Attendance::whereHas('users', function ($query)  use($userId) {
            $query->where('user_id', $userId)->whereNotNull('clock_out_at');
        })->with(['users' => function ($query) use($userId) {
            $query->where('user_id', $userId);
        }])->find($attendance->id);


        return response()->json([
            'success' => true,
            'data' => $userAtt->users()->first()->pivot
        ]);
    }
}
