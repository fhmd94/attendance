<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Auth\AuthenticationException;

class AuthenticationController extends Controller
{
    public function authenticate(Request $request)
    {
        $credentials = $request->only('email', 'password');

        //valid credential
        $validator = Validator::make($credentials, [
            'email' => 'required|email',
            'password' => 'required|string|min:6|max:50'
        ]);

        //Send failed response if request is not valid
        if ($validator->fails()) {
            return response()->json(['error' => $validator->messages()], 200);
        }

        if (!Auth::attempt($credentials)) {
            throw new AuthenticationException;
        }
        $user = request()->user();

        return response()->json([
            'success' => true,
            'token' => $user->token,
            'role' => $user->role
        ]);
    }

    public function logout()
    {
        Auth::logout();

        return response()->json([
            'success' => true,
        ]);
    }
}
