<?php

namespace App\Http\Controllers\Api;

use Carbon\Carbon;
use App\Models\User;
use App\Models\Attendance;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ReportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = [];

        $users = User::all();
        foreach ($users as $user) {
            $item = [];
            $item['id'] = $user->id;
            $item['name'] = $user->name;
            $item['attendance'] = $user->attendance->map(function ($value) {
                return ['date' => $value->day, 'clock_in' => $value->pivot->clock_in_at, 'clock_out' => $value->pivot->clock_out_at];
            });
            $data[] = $item;
        }

        $meta = [];
        $Attendance = Attendance::all();
        foreach ($Attendance as $key => $value) {
            $_item = [];
            $_item['date'] = $value->day;
            $_item['date_string'] = Carbon::parse($value->day)->format('F, d M Y');
            $meta[] = $_item;
        }

        return response()->json([
            'data' => $data,
            'meta' => $meta
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

        $Attendance = Attendance::get();
        $data = [];
        foreach ($Attendance as $key => $item) {
            $_item = [];
            $_item['day'] = $item->day;

            $user = User::whereHas('attendance', function ($q) use($item) {
                $q->where('attendance_id', $item->id);
            })->with(['attendance' => function ($q) use($item) {
                $q->where('attendance_id', $item->id);
            }])->find($id);
            if ($user) {
                $_item['clock_in'] = $user->attendance[0]->pivot->clock_in_at;
                $_item['clock_out'] = $user->attendance[0]->pivot->clock_out_at;
            } else {
                $_item['clock_in'] = '';;
                $_item['clock_out'] = '';
            }

            $data[] = $_item;
        }
        return response()->json([
            'data' => $data
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
