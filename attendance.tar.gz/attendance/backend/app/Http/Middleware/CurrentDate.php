<?php

namespace App\Http\Middleware;

use Closure;
use Carbon\Carbon;
use App\Models\Attendance;
use Illuminate\Http\Request;

class CurrentDate
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $attendance = Attendance::where('day', Carbon::now()->format('Y-m-d'))->first();
        if (!$attendance) {
            \abort(400, "Absensi untuk hari ini belum di generate");
        }
        $request['attendance'] = $attendance;

        return $next($request);
    }
}
