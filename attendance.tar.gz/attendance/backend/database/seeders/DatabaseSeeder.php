<?php

namespace Database\Seeders;

use Carbon\Carbon;
use App\Models\User;
use App\Models\Attendance;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        User::factory()
            ->create([
                'email' => 'attendance@admin.com',
                'password' => bcrypt('password'),
                'role' => 'admin'
            ]);

        User::factory(10)
            ->create();

        $startDate = '2021-01-03';
        Attendance::factory(3)
            ->sequence(fn ($sequence) => [
                'day' => Carbon::parse($startDate)->addDays($sequence->index)->format('Y-m-d'),
                'url_qr_code' => url('qr_code/'.Carbon::parse($startDate)->addDays($sequence->index)->timestamp.'.png')
            ])
            ->create();

        $attendances = Attendance::all();
        foreach ($attendances as $key => $attendance) {
            foreach (User::all() as $user) {
                $faker = \Faker\Factory::create();
                $attendance->users()->attach($user->id, [
                    'clock_in_at' => Carbon::parse($attendance->day),
                    'clock_out_at' => Carbon::parse($attendance->day),
                    'latitude' => $faker->latitude(),
                    'longitude' => $faker->longitude(),
                ]);
            }
        }
    }
}
