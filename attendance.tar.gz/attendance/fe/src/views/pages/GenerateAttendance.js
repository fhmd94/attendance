import moment from 'moment'
import React, { Component } from 'react'
import { Segment, Button } from 'semantic-ui-react'
import { http } from '../../libs/axios'

export default class Home extends Component{

    generateData = (event) => {
        let token = localStorage.getItem('access_token')
        http.post('attendance?token='+token, {
            day: moment().format('YYYY-MM-DD')
        }).then(({data}) => {
            alert("Success Generate Qr Code")
        }).catch((e) => {
            alert("Error Generate Qr Code")
        })
    }

    render() {
        return(
            <Segment>
                <Button.Group vertical labeled icon>
                    <Button icon='file' content='Genarate QR Code' onClick={this.generateData} />
                </Button.Group>
            </Segment>
        )
    }
}