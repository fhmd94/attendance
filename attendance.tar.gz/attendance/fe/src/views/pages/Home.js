import React, { Component } from 'react'
import { Segment, Table, Item, Image } from 'semantic-ui-react'
import { http } from '../../libs/axios'
import moment from 'moment'

export default class Home extends Component{
    state = {profile: {}, data: []}

    componentDidMount() {
        this.fetchData()
    }

    fetchData() {
        const token = localStorage.getItem('access_token');
        http.get('account/me?token='+token)
        .then(({data}) => {
            this.setState({data: data.attendance, profile:{name: data.name, role: data.role, email: data.email}})
        })
    }

    render() {
        const list = []

        this.state.data.forEach((data) => {
            list.push(<Table.Row>
                <Table.Cell>{moment(data.day).format('DD MMMM YYYY')}</Table.Cell>
                <Table.Cell>{moment(data.pivot.clock_in_at).format('h:mm:ss')}</Table.Cell>
                <Table.Cell>{moment(data.pivot.clock_out_at).format('h:mm:ss')}</Table.Cell>
            </Table.Row>)
        })
        return(
            <Segment>
                <Item.Group>
                    <Item>
                    <Item.Image size='tiny' src='https://react.semantic-ui.com/images/wireframe/image.png' />

                    <Item.Content>
                        <Item.Header text-left>{this.state.profile.name}</Item.Header>
                        <Item.Meta>{this.state.profile.role}</Item.Meta>
                        <Item.Extra>{this.state.profile.email}</Item.Extra>
                    </Item.Content>
                    </Item>
                </Item.Group>

                <Table celled>
                    <Table.Header>
                    <Table.Row>
                        <Table.HeaderCell>Date</Table.HeaderCell>
                        <Table.HeaderCell>Clock In</Table.HeaderCell>
                        <Table.HeaderCell>Clock Out</Table.HeaderCell>
                    </Table.Row>
                    </Table.Header>

                    <Table.Body>
                        {list}
                    </Table.Body>
                </Table>
            </Segment>
        )
    }
}