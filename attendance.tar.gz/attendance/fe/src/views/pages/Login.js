import React from 'react'
import { Redirect } from 'react-router-dom'
import { Button, Form, Grid, Header, Image, Segment } from 'semantic-ui-react'
import logo from '../../logo.svg';
import { http } from '../../libs/axios'

export default class Login extends React.Component {
  state = { email: '', password: '', redirectTo: null }

  handleChangeEmail = (e) => {
    const value = e.target.value;
    this.setState({email: value})
  };

  handleChangePassword = (e) => {
    const value = e.target.value;
    this.setState({password: value})
  };

  handleSubmit = (e) => {
    e.preventDefault();
    http.post('login', {
      'email': this.state.email,
      'password': this.state.password
    }).then(({data}) => {
      localStorage.setItem("access_token", data.token);
      if(data.role !== '') {
        localStorage.setItem("role", data.role);
      }
      localStorage.setItem("role", data.role);
      this.setState({redirectTo: '/'})
    }).catch(error => {
      console.log(error)
    }) 
    console.log(this.state)
  }

  render() {
    if (this.state.redirectTo) {
      return <Redirect to={this.state.redirectTo} />
    }
    return (
      <>
        <Grid textAlign='center' style={{ height: '100vh' }} verticalAlign='middle'>
          <Grid.Column style={{ maxWidth: 450 }}>
            <Header as='h2' color='teal' textAlign='center'>
              <Image src={logo} /> Log-in Attendance
            </Header>
            <Form size='large' onSubmit={this.handleSubmit}>
              <Segment stacked>
                <Form.Input fluid icon='user' iconPosition='left' placeholder='E-mail address' id="email" name="email" 
                  onChange={this.handleChangeEmail} />
                <Form.Input
                  fluid
                  icon='lock'
                  iconPosition='left'
                  placeholder='Password'
                  type='password'
                  id="password"
                  name="password"
                  onChange={this.handleChangePassword}
                />
      
                <Button color='teal' fluid size='large'>
                  Login
                </Button>
              </Segment>
            </Form>
          </Grid.Column>
        </Grid>
      </>
    )
  }
}

