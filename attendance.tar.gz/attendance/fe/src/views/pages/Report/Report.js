import React, { Component } from 'react'
import {Select, Segment, Table } from 'semantic-ui-react'
import { http } from '../../../libs/axios';
import moment from 'moment'

const loading = (
<div className="pt-3 text-center">
    <div className="sk-spinner sk-spinner-pulse"></div>
</div>
);


export default class Report extends Component{
    state = { 
        selected: '',
        users: [],
        data: []
    }
    componentDidMount() {
        this.fetchUsers()
    }

    fetchUsers() {
        let token = localStorage.getItem('access_token')
        http.get('list-users?token='+token)
            .then(({data}) => {
                this.setState({users: data.data})
            })
    }
    handleChange = (event, param) => {
        let token = localStorage.getItem('access_token')
        console.log(event)
        http.get('report/'+param.value+'?token='+token)
            .then(({data}) => {
                console.log(data.data)
                this.setState({data: data.data})
            })
    }

    render() {
        const { selected, data } = this.state;
        const list = []
        data.forEach((item, key) => {
            console.log(item)
            list.push(<Table.Row key={key}>
                <Table.Cell>{moment(item.day).format('DD MMMM YYYY')} { item.day }</Table.Cell>
                <Table.Cell>{item.clock_out !== '' ? moment(item.clock_in).format('h:mm:ss') : ''}</Table.Cell>
                <Table.Cell>{item.clock_out !== '' ? moment(item.clock_out).format('h:mm:ss') : ''}</Table.Cell>
            </Table.Row>)
        })
        return(
            <Segment>
                <Select placeholder='Select Users' options={this.state.users} onChange={this.handleChange} value={selected}/>


                <Table celled>
                    <Table.Header>
                    <Table.Row>
                        <Table.HeaderCell>Date</Table.HeaderCell>
                        <Table.HeaderCell>Clock In</Table.HeaderCell>
                        <Table.HeaderCell>Clock Out</Table.HeaderCell>
                    </Table.Row>
                    </Table.Header>

                    <Table.Body>
                        {list}
                    </Table.Body>
                </Table>
            </Segment>
        )
    }
}