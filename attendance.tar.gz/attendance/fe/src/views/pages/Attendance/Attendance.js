import React, { Component, Suspense } from 'react'
import { Redirect, Switch, Link, Route } from 'react-router-dom';
import {Menu, Icon } from 'semantic-ui-react'

const loading = (
<div className="pt-3 text-center">
    <div className="sk-spinner sk-spinner-pulse"></div>
</div>
);

const ClockIn = React.lazy(() => import('./ClockIn'));
const ClockOut = React.lazy(() => import('./ClockOut'));
const routes = [
    { path: '/', exact: true, name: 'Attendance' },
    { path: '/attendance/clock-in', name: 'Clock In', component: ClockIn },
    { path: '/attendance/clock-out', name: 'Clock Out', component: ClockOut },
];

export default class Attendance extends Component{

    render() {
        return(
            <div>
                <Suspense fallback={loading}>
                    <Switch>
                        {
                            routes.map((route, idx) => {
                                return route.component && (
                                    <Route 
                                        key={idx}
                                        path={route.path}
                                        exact={route.exact}
                                        name={route.name}
                                        render={(props) => 
                                            (
                                                <div>
                                                    <route.component {...props} />
                                                </div>
                                            )
                                        }
                                    />
                                )
                            })
                        }
                        <Redirect from="/" to="/attendance" />
                    </Switch>
                </Suspense>
                
                <Menu compact icon='labeled' widths="2">
                    <Menu.Item 
                        as={Link}
                        to='/attendance/clock-in'
                        name='in'>
                        <Icon name='clock' />
                        Clock In
                    </Menu.Item>
                    <Menu.Item name='out'
                        as={Link}
                        to='/attendance/clock-out'>
                        <Icon name='clock' />
                        Clock Out
                    </Menu.Item>
                </Menu>
            </div>
        )
    }
}