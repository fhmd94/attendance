import React, { Component } from 'react'
import { Segment } from 'semantic-ui-react'
import QrReader from 'react-qr-reader'

import { http } from '../../../libs/axios'

export default class ClockIn extends Component{
    state = {
        result: 'No result',
        latitude: null,
        longitude: null,
        date: '',
        token_attendance: ''
    }

    componentDidMount() {
        navigator.geolocation.getCurrentPosition((position) => {
          this.setState({latitude: position.coords.latitude, longitude: position.coords.longitude})
        })
    }
     
    handleScan = data => {
        if (data) {
            var jsonData = JSON.parse(data)
            this.setState({
                date: jsonData.date,
                token_attendance: jsonData.token
            })

            const token = localStorage.getItem('access_token');
            http.post('clock-in?token='+token, {
                "date": this.state.date,
                "latitude": this.state.latitude,
                "longitude": this.state.longitude,
                "token_attendance": this.state.token_attendance
            }).then(({data}) => {
                alert("Attendance Success")
                this.setState({redirectTo: 'attendance'})
            }).catch((error) => {
                this.setState({redirectTo: 'attendance'})
                alert(error.message)
            })
        }
    }
    handleError = err => {
        alert(err.message)
        console.error(err)
    }

    render() {
        return(
            <div id="app">
                <Segment>
                    <QrReader
                        delay={300}
                        onError={this.handleError}
                        onScan={this.handleScan}
                        style={{ width: '100%' }}
                    />
                    <p>{JSON.stringify(this.state)}</p>
                    Attendance
                </Segment>
            </div>
        )
    }
}