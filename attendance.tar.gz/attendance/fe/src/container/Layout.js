import React, { Component, Suspense } from 'react'
import { Segment, Menu, Icon, Header } from 'semantic-ui-react'
import { Redirect, Switch, Link, Route } from 'react-router-dom';

const loading = (
<div className="pt-3 text-center">
    <div className="sk-spinner sk-spinner-pulse"></div>
</div>
);

const Home = React.lazy(() => import('../views/pages/Home'));
const Attendance = React.lazy(() => import('../views/pages/Attendance/Attendance'));
const Report = React.lazy(() => import('../views/pages/Report/Report'));
const GenerateAttendace = React.lazy(() => import('../views/pages/GenerateAttendance'));
const routes = [
    { path: '/', exact: true, name: 'Home', component: Home },
    { path: '/attendance', name: 'Attendance', component: Attendance },
    { path: '/reports', name: 'Report', component: Report },
    { path: '/generate', name: 'Report', component: GenerateAttendace },
];

export default class Layout extends Component{
    state = { activeItem: 'home', widths: 2, role: '' }

    componentDidMount() {
        const role = localStorage.getItem('role');
        if (role === 'admin') {
            this.setState({widths: 4, role: role})
        }
    }

    handleItemClick = (e, { name }) => {
        this.setState({ activeItem: name })
    }

    render() {
        const { activeItem } = this.state
        let menu = [];
        if (this.state.role === 'admin'){
            menu.push(<Menu.Item name='report'
                as={Link}
                to='/reports'
                active={activeItem === 'report'}
                onClick={this.handleItemClick}>
                <Icon name='file' />
                Report
            </Menu.Item>)
            
            menu.push(<Menu.Item name='generate'
                as={Link}
                to='/generate'
                active={activeItem === 'generate'}
                onClick={this.handleItemClick}>
                <Icon name='file' />
                Generate Attendance
            </Menu.Item>)
            
        }

        return(
            <div id="app">
                <Menu attached="top">
                    <Segment attached="top" inverted>
                        <Header as="h3">Attendance</Header>
                    </Segment>
                </Menu>

                <Suspense fallback={loading}>
                    <Switch>
                        {
                            routes.map((route, idx) => {
                                return route.component && (
                                    <Route 
                                        key={idx}
                                        path={route.path}
                                        exact={route.exact}
                                        name={route.name}
                                        render={(props) => 
                                            localStorage.getItem("access_token")
                                            // true 
                                            ? (
                                                <div>
                                                    <route.component {...props} />
                                                </div>
                                            ) : (
                                                <Redirect to="/login" />
                                            )
                                        }
                                    />
                                )
                            })
                        }
                    </Switch>
                </Suspense>

                <div id="menu-bottom">
                    <Menu attached='bottom' compact icon='labeled' widths={this.state.widths}>
                        <Menu.Item 
                            as={Link}
                            to='/'
                            name='home' 
                            active={activeItem === 'home'}
                            onClick={this.handleItemClick}>
                            <Icon name='home' />
                            Home
                        </Menu.Item>
                        <Menu.Item name='scan'
                            as={Link}
                            to='/attendance'
                            active={activeItem === 'scan'}
                            onClick={this.handleItemClick}>
                            <Icon name='calendar' />
                            Attendance
                        </Menu.Item>
                        {menu}
                    </Menu>
                </div>
            </div>
        )
    }
}